﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LatajacyObrazek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int ilosc = 0;
        int czas = 30;

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int x = this.Width / 2;
            int y = this.Height / 2;
            int u = this.Width-200;
            int k = this.Height-100;


            int a = this.Width / 2 -290;
            int b = 0;

            Point punkt = new Point(x, y);
            Point punkt2 = new Point(a, b);
            Point punkt3 = new Point(u, k);

            this.WindowState = FormWindowState.Maximized;
            pictureBox1.Location = punkt;
            label1.Location = punkt2;
            label2.Text = "Punkty: " + ilosc.ToString();
            label2.Location = punkt3;

            label3.Text = "Czas: 00:" + czas;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Random los = new Random();
            int x = los.Next(100, this.Width - 100);
            int y = los.Next(100, this.Height - 100);
            Point punkt = new Point(x, y);
            pictureBox1.Location = punkt;
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            ilosc++;
            label2.Text = "Punkty: " + ilosc.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Click(object sender, EventArgs e)
        {
            ilosc--;
            label2.Text = "Punkty: " + ilosc.ToString();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            czas--;
            if (czas < 10)
                label3.Text = "Czas: 00:0" + czas;
            else
                label3.Text = "Czas: 00:" + czas;
        }
    }
}
